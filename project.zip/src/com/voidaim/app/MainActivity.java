package com.voidaim.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import java.io.OutputStream;
import java.net.UnixDomainSocketAddress;
import java.nio.channels.SocketChannel;

public class MainActivity extends Activity {
    private TextView tvStatus;
    private SocketChannel socket;
    private static final String SOCKET_PATH = "/data/local/tmp/voidaim.sock";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        Button btnInject = findViewById(R.id.btnInject);
        Button btnStop = findViewById(R.id.btnStop);
        Switch swGod = findViewById(R.id.swGodMode);

        swGod.setOnCheckedChangeListener((v, isChecked) -> sendCommand("god " + (isChecked ? "1" : "0")));

        btnInject.setOnClickListener(v -> {
            tvStatus.setText("Status: Injecting...");
            tvStatus.setTextColor(0xFFFFAA00);
            // Тут должен быть вызов твоего нативного инжектора (KittyInjector)
            // Например: NativeLib.inject();
        });

        btnStop.setOnClickListener(v -> {
            sendCommand("stop 1");
            tvStatus.setText("Status: Stopped");
            tvStatus.setTextColor(0xFFFF4444);
        });
    }

    private void sendCommand(String cmd) {
        new Thread(() -> {
            try {
                if (socket == null || !socket.isConnected()) {
                    socket = SocketChannel.open(UnixDomainSocketAddress.of(SOCKET_PATH));
                }
                OutputStream os = socket.socket().getOutputStream();
                os.write((cmd + "\n").getBytes());
                os.flush();
            } catch (Exception e) {
                runOnUiThread(() -> tvStatus.setText("Error: Run Inject first"));
            }
        }).start();
    }
}
